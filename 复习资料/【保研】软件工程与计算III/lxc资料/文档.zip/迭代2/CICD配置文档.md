# CI/CD - Gitlab Runner 配置文档

## 概要

我们使用软院云上的一台服务器完成了本次部署 gitlab runner 实现 CICD 的任务。

## 部署流程

### 下载 gitlab-runner ELF 文件

使用以下命令下载 gitlab-runner 的 ELF 文件，并为该文件添加可执行权限：

~~~bash
sudo curl -L --output /usr/local/bin/gitlab-runner https://gitlab-runner-downloads.s3.amazonaws.com/latest/binaries/gitlab-runner-linux-amd64
sudo chmod +x /usr/local/bin/gitlab-runner
~~~

### 添加运行 gitlab-runner 的用户

为 gitlab-runner 的运行分配一个专用用户空间，并在该用户空间中完成 gitlab-runner 的安装：

~~~bash
sudo useradd --comment 'GitLab Runner' --create-home gitlab-runner --shell /bin/zsh
sudo gitlab-runner install --user=gitlab-runner --working-directory=/home/gitlab-runner
~~~

### 启动 gitlab-runner 并查看运行状态

~~~bash
su gitlab-runner
sudo gitlab-runner start
sudo systemctl status gitlab-runner
~~~

最后一步得到 gitlab-runner 服务的状态为 `active`，说明 Gitlab-Runner 的部署完成

## 注册流程

在项目设置的 CICD-Runner 栏中新建项目 Runner，然后按照说明注册即可，我们使用 docker 中 `node:21.7.3` 镜像容器作为运行环境

~~~bash
gitlab-runner register --url http://172.29.4.49  --token <token>
~~~

## 编写流水线

在团队的 CI/CD 设置中设置变量，并在前端与后端项目的 `.gitlab-ci.yml` 文件中编写流水线。

前端流水线如下：

~~~yaml
image: 'node:21.7.3'

variables:
  HTTP_PROXY: ${HTTP_PROXY}
  HTTPS_PROXY: ${HTTP_PROXY}

stages:
  - build
  - deploy

build-job:
  stage: build
  script:
    - yarn install
    - npm run build
    - tar -czvf frontend.tar.gz dist/*
    - echo "Build Done🚀!"
  artifacts:
    paths:
      - frontend.tar.gz

deploy-job:
  stage: deploy
  environment: production
  before_script:
    - echo "$GITLAB_RUNNER_PRIVATE_KEY" > deploy.key
    - chmod 0600 deploy.key
    - '[ -f  ~/.ssh/known_hosts ] && rm ~/.ssh/known_hosts'
  script:
    - scp -o StrictHostKeyChecking=no -i deploy.key frontend.tar.gz root@172.29.7.254:/root/webhook/
    # Call server to pull and deploy new code
    - curl -v http://172.29.7.254:11451/hooks/frontend
    - echo "Deploy Done🚀!"
    - rm deploy.key
~~~

后端流水线如下：

~~~yaml
image: 'node:21.7.3'

variables:
  HTTP_PROXY: ${HTTP_PROXY}
  HTTPS_PROXY: ${HTTP_PROXY}

stages:
  - build
  - deploy

build-job:
  stage: build
  script:
    - npm install
    - cd ..
    - tar -czvf backend.tar.gz backend
    - mv backend.tar.gz backend
    - echo "Build Done🚀!"
  artifacts:
    paths:
      - backend.tar.gz

deploy-job:
  stage: deploy
  environment: production
  before_script:
    - echo "$GITLAB_RUNNER_PRIVATE_KEY" > deploy.key
    - chmod 0600 deploy.key
    - '[ -f  ~/.ssh/known_hosts ] && rm ~/.ssh/known_hosts'
  script:
    - scp -o StrictHostKeyChecking=no -i deploy.key backend.tar.gz root@172.29.7.254:/root/webhook/
    # Call server to pull and deploy new code
    - curl -v http://172.29.7.254:11451/hooks/backend
    - echo "Deploy Done🚀!"
    - rm deploy.key
~~~

## 运行记录

前端的成功构建截图如下：

![cicd-frontend](assets/cicd-frontend.png)

后端的成功构建截图如下：
![cicd-backend](assets/cicd-backend.png)